[![Build Status](https://github.com/arl/gitstatus/actions/workflows/tests.yml/badge.svg)](https://github.com/arl/gitstatus/actions/workflows/tests.yml)
[![Go Report Card](https://goreportcard.com/badge/github.com/arl/gitstatus)](https://goreportcard.com/report/github.com/arl/gitstatus)
[![Go Reference](https://pkg.go.dev/badge/github.com/arl/gitstatus.svg)](https://pkg.go.dev/github.com/arl/gitstatus) 

# gitstatus


## retrieve the Git status of a working tree, in Go.



## License MIT

See [LICENSE file](./LICENSE)
